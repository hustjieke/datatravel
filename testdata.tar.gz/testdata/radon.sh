mysql -uradon -pSun55_kongg -h192.168.0.253 -P3306
