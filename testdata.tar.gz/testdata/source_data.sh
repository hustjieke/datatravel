nohup mysql -uradon -pSun55_kongg -h192.168.0.253 -P3306 -e "use other;source other/scheduler_run_details.sql;" > nohup_1 2>&1 &
