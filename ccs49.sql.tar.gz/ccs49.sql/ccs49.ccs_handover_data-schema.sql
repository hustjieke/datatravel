CREATE TABLE `ccs_handover_data` (
  `handover_data_id` varchar(35) NOT NULL COMMENT '交接数据id',
  `handover_work_id` varchar(35) DEFAULT NULL COMMENT '交接作业id',
  `collection_time` datetime DEFAULT NULL COMMENT '采集时间',
  `handover_data_value` float DEFAULT NULL COMMENT '采集数据值',
  PRIMARY KEY (`handover_data_id`),
  KEY `COLLECTION_TIME_INDEX` (`collection_time`),
  KEY `HANDOVER_WORK_ID_INDEX` (`handover_work_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 PARTITION BY HASH(`handover_data_id`);
