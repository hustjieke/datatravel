CREATE TABLE `ccs_dev_data_record` (
  `ccs_dev_data_record_id` varchar(35) NOT NULL COMMENT '设备实时上报数据ID',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `dev_code` varchar(50) DEFAULT NULL COMMENT '设备编号',
  `dev_actval` float NOT NULL COMMENT '设备上报值 温度/湿度',
  `data_type` char(1) NOT NULL COMMENT '数据类型',
  `ccs_dev_id` varchar(35) NOT NULL COMMENT '设备ID',
  `insert_time` datetime DEFAULT NULL COMMENT '插入时间',
  PRIMARY KEY (`ccs_dev_data_record_id`),
  KEY `IDX_DATARECORD_CREATETIME` (`create_time`),
  KEY `IDX_DATARECORD_DEVCODE` (`dev_code`,`ccs_dev_id`)
) ENGINE=TokuDB DEFAULT CHARSET=utf8 PARTITION BY HASH(`ccs_dev_data_record_id`);
