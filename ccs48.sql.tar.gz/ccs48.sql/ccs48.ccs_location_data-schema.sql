CREATE TABLE `ccs_location_data` (
  `location_data_id` varchar(35) NOT NULL COMMENT '定位数据id',
  `location_data_collection_time` datetime DEFAULT NULL COMMENT '采集时间',
  `location_data_insert_time` datetime DEFAULT NULL COMMENT '插入时间',
  `dev_no` varchar(50) DEFAULT NULL COMMENT '设备编码',
  `location_data_longitude` double DEFAULT NULL COMMENT '经度',
  `location_data_latitude` double DEFAULT NULL COMMENT '纬度',
  `location_data_altitude` double DEFAULT NULL,
  PRIMARY KEY (`location_data_id`),
  KEY `dev_no_index` (`dev_no`),
  KEY `location_data_collection_time_index` (`location_data_collection_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 PARTITION BY HASH(`location_data_id`); 
